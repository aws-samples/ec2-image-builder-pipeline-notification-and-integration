def lambda_handler(event, context):
    # Sample Lambda Code block
    print("A new AMI has been created")
    # Integration with other AWS services